
import { createClient } from '@lumi.new/sdk'

export const lumi = createClient({
    "projectId": "p348599054874132480",
    "apiBaseUrl": "https://api.lumi.new",
    "authOrigin": "https://auth.lumi.new",
})
    