
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  ShoppingBag, 
  Settings, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar,
  FileText,
  Download,
  Eye,
  X,
  Edit,
  Save,
  Cancel
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useInvoices } from '../hooks/useInvoices';
import toast from 'react-hot-toast';

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postalCode: string;
}

interface Purchase {
  _id: string;
  invoiceNumber: string;
  serviceName: string;
  totalAmount: number;
  status: 'paid' | 'pending' | 'cancelled';
  date: string;
}

const ClientPortal: React.FC = () => {
  const { t } = useLanguage();
  const { searchInvoices } = useInvoices();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: ''
  });
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editProfile, setEditProfile] = useState<UserProfile>({ ...userProfile });

  // 🔐 Vérification authentification au chargement
  useEffect(() => {
    const savedAuth = localStorage.getItem('jj_client_auth');
    const savedEmail = localStorage.getItem('jj_client_email');
    
    if (savedAuth === 'true' && savedEmail) {
      setIsAuthenticated(true);
      setUserEmail(savedEmail);
      loadUserData(savedEmail);
    }
  }, []);

  // 📊 Chargement des données utilisateur
  const loadUserData = async (email: string) => {
    try {
      const invoices = await searchInvoices(email);
      if (invoices && invoices.length > 0) {
        const purchaseData = invoices.map(invoice => ({
          _id: invoice._id,
          invoiceNumber: invoice.invoiceNumber,
          serviceName: invoice.serviceName,
          totalAmount: invoice.totalAmount,
          status: invoice.status,
          date: invoice.createdAt
        }));
        setPurchases(purchaseData);
        
        // Charger profil depuis première facture
        const firstInvoice = invoices[0];
        setUserProfile({
          name: firstInvoice.customerName || '',
          email: firstInvoice.customerEmail || email,
          phone: firstInvoice.customerPhone || '',
          address: '',
          city: '',
          postalCode: ''
        });
        setEditProfile({
          name: firstInvoice.customerName || '',
          email: firstInvoice.customerEmail || email,
          phone: firstInvoice.customerPhone || '',
          address: '',
          city: '',
          postalCode: ''
        });
      }
    } catch (error) {
      console.error('Erreur chargement données:', error);
    }
  };

  // 🔑 Connexion
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail) return;

    setIsLoading(true);
    try {
      // Simulation authentification
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      localStorage.setItem('jj_client_auth', 'true');
      localStorage.setItem('jj_client_email', loginEmail);
      
      setIsAuthenticated(true);
      setUserEmail(loginEmail);
      await loadUserData(loginEmail);
      
      toast.success('Connexion réussie !');
    } catch (error) {
      toast.error('Erreur de connexion');
    } finally {
      setIsLoading(false);
    }
  };

  // 🚪 Déconnexion
  const handleLogout = () => {
    localStorage.removeItem('jj_client_auth');
    localStorage.removeItem('jj_client_email');
    setIsAuthenticated(false);
    setUserEmail('');
    setPurchases([]);
    setUserProfile({
      name: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      postalCode: ''
    });
    toast.success('Déconnexion réussie');
  };

  // ✏️ Modification profil
  const handleEditProfile = () => {
    setIsEditingProfile(true);
    setEditProfile({ ...userProfile });
  };

  const handleSaveProfile = () => {
    setUserProfile({ ...editProfile });
    setIsEditingProfile(false);
    toast.success('Profil mis à jour');
  };

  const handleCancelEdit = () => {
    setEditProfile({ ...userProfile });
    setIsEditingProfile(false);
  };

  // 🎨 Interface de connexion
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8"
        >
          <div className="text-center mb-8">
            <div className="bg-blue-100 dark:bg-blue-900/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <User className="h-8 w-8 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              Espace Client
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              Connectez-vous pour accéder à vos factures et informations
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Adresse email
              </label>
              <input
                type="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="votre@email.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Mot de passe
              </label>
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="••••••••"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                'Se connecter'
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Pas encore de compte ?{' '}
              <a href="/register" className="text-blue-600 hover:text-blue-700">
                Créer un compte
              </a>
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  // 🏠 Interface principale espace client
  const tabs = [
    { id: 'dashboard', label: 'Tableau de bord', icon: User },
    { id: 'purchases', label: 'Mes achats', icon: ShoppingBag },
    { id: 'profile', label: 'Mon profil', icon: Settings },
    { id: 'contact', label: 'Contact', icon: Phone }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Espace Client
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Bienvenue, {userProfile.name || userEmail}
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              Déconnexion
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4">
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                      }`}
                    >
                      <Icon className="h-5 w-5 mr-3" />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Contenu */}
          <div className="lg:col-span-3">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
              {/* Tableau de bord */}
              {activeTab === 'dashboard' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                    Tableau de bord
                  </h2>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg">
                      <div className="flex items-center">
                        <ShoppingBag className="h-8 w-8 text-blue-600 mr-3" />
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Total achats</p>
                          <p className="text-2xl font-bold text-gray-900 dark:text-white">
                            {purchases.length}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg">
                      <div className="flex items-center">
                        <FileText className="h-8 w-8 text-green-600 mr-3" />
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Factures payées</p>
                          <p className="text-2xl font-bold text-gray-900 dark:text-white">
                            {purchases.filter(p => p.status === 'paid').length}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-yellow-50 dark:bg-yellow-900/20 p-6 rounded-lg">
                      <div className="flex items-center">
                        <Calendar className="h-8 w-8 text-yellow-600 mr-3" />
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">En attente</p>
                          <p className="text-2xl font-bold text-gray-900 dark:text-white">
                            {purchases.filter(p => p.status === 'pending').length}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Mes achats */}
              {activeTab === 'purchases' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                    Mes achats
                  </h2>
                  {purchases.length === 0 ? (
                    <div className="text-center py-12">
                      <ShoppingBag className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 dark:text-gray-400">
                        Aucun achat trouvé
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {purchases.map((purchase) => (
                        <div
                          key={purchase._id}
                          className="border border-gray-200 dark:border-gray-700 rounded-lg p-4"
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-gray-900 dark:text-white">
                                {purchase.serviceName}
                              </h3>
                              <p className="text-sm text-gray-500 dark:text-gray-400">
                                Facture #{purchase.invoiceNumber}
                              </p>
                              <p className="text-sm text-gray-500 dark:text-gray-400">
                                {new Date(purchase.date).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="text-lg font-bold text-gray-900 dark:text-white">
                                {purchase.totalAmount.toFixed(2)} $ CAD
                              </p>
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(purchase.status)}`}>
                                {purchase.status === 'paid' ? 'Payé' : 
                                 purchase.status === 'pending' ? 'En attente' : 'Annulé'}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Mon profil */}
              {activeTab === 'profile' && (
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                      Mon profil
                    </h2>
                    {!isEditingProfile && (
                      <button
                        onClick={handleEditProfile}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Modifier
                      </button>
                    )}
                  </div>

                  {isEditingProfile ? (
                    <form className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Nom complet
                          </label>
                          <input
                            type="text"
                            value={editProfile.name}
                            onChange={(e) => setEditProfile({...editProfile, name: e.target.value})}
                            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Email
                          </label>
                          <input
                            type="email"
                            value={editProfile.email}
                            onChange={(e) => setEditProfile({...editProfile, email: e.target.value})}
                            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Téléphone
                          </label>
                          <input
                            type="tel"
                            value={editProfile.phone}
                            onChange={(e) => setEditProfile({...editProfile, phone: e.target.value})}
                            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Ville
                          </label>
                          <input
                            type="text"
                            value={editProfile.city}
                            onChange={(e) => setEditProfile({...editProfile, city: e.target.value})}
                            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Adresse
                        </label>
                        <input
                          type="text"
                          value={editProfile.address}
                          onChange={(e) => setEditProfile({...editProfile, address: e.target.value})}
                          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        />
                      </div>

                      <div className="flex space-x-4">
                        <button
                          type="button"
                          onClick={handleSaveProfile}
                          className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center"
                        >
                          <Save className="h-4 w-4 mr-2" />
                          Sauvegarder
                        </button>
                        <button
                          type="button"
                          onClick={handleCancelEdit}
                          className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors flex items-center"
                        >
                          <X className="h-4 w-4 mr-2" />
                          Annuler
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-500 dark:text-gray-400">
                            Nom complet
                          </label>
                          <p className="text-lg text-gray-900 dark:text-white">
                            {userProfile.name || 'Non renseigné'}
                          </p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-500 dark:text-gray-400">
                            Email
                          </label>
                          <p className="text-lg text-gray-900 dark:text-white">
                            {userProfile.email}
                          </p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-500 dark:text-gray-400">
                            Téléphone
                          </label>
                          <p className="text-lg text-gray-900 dark:text-white">
                            {userProfile.phone || 'Non renseigné'}
                          </p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-500 dark:text-gray-400">
                            Ville
                          </label>
                          <p className="text-lg text-gray-900 dark:text-white">
                            {userProfile.city || 'Non renseigné'}
                          </p>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-500 dark:text-gray-400">
                          Adresse
                        </label>
                        <p className="text-lg text-gray-900 dark:text-white">
                          {userProfile.address || 'Non renseigné'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Contact */}
              {activeTab === 'contact' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                    Nous contacter
                  </h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <Phone className="h-6 w-6 text-red-600 mr-3" />
                        <div>
                          <p className="font-semibold text-gray-900 dark:text-white">Téléphone</p>
                          <p className="text-gray-600 dark:text-gray-300">(514) 555-0123</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Mail className="h-6 w-6 text-red-600 mr-3" />
                        <div>
                          <p className="font-semibold text-gray-900 dark:text-white">Email</p>
                          <p className="text-gray-600 dark:text-gray-300">info@jjmecanique.ca</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <MapPin className="h-6 w-6 text-red-600 mr-3 mt-1" />
                        <div>
                          <p className="font-semibold text-gray-900 dark:text-white">Zone de service</p>
                          <p className="text-gray-600 dark:text-gray-300">
                            Montréal et environs<br />
                            Rayon de 100 km
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                        Heures d'ouverture
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300">
                        Lundi au dimanche<br />
                        8h00 à 18h00
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientPortal;
