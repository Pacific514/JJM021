
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Calendar } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';
import LanguageToggle from './LanguageToggle';
import ThemeToggle from './ThemeToggle';
import ResponsiveLogo from './ResponsiveLogo';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t, language } = useLanguage();
  const { theme } = useTheme();
  const location = useLocation();

  const isActivePage = (path: string) => {
    return location.pathname === path;
  };

  const navItems = [
    { path: '/', label: t('nav.home') },
    { path: '/services', label: t('nav.services') },
    { path: '/calculator', label: language === 'fr' ? 'Estimation' : 'Estimate' },
    { path: '/contact', label: t('nav.contact') }
  ];

  return (
    <header className="relative sticky top-0 z-50 overflow-hidden">
      {/* Arrière-plan avec gradients et effets */}
      <div className="absolute inset-0 bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 via-transparent to-blue-900/20"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-3xl"></div>
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0 z-10">
            <div className="transform scale-110 sm:scale-125 md:scale-100 origin-left">
              <ResponsiveLogo />
            </div>
          </Link>

          {/* Navigation desktop - CENTRÉ */}
          <nav className="hidden lg:flex items-center justify-center flex-1 mx-8">
            <div className="flex items-center space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 ${
                    isActivePage(item.path)
                      ? 'text-red-400 bg-red-900/30 shadow-lg shadow-red-500/20'
                      : 'text-white hover:text-red-400 hover:bg-red-900/20 hover:shadow-lg hover:shadow-red-500/10'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </nav>

          {/* Actions desktop */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Bouton rouge - Réservation */}
            <Link
              to="/service-booking"
              className="flex items-center bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white px-4 py-2 rounded-lg transition-all duration-300 font-semibold shadow-lg shadow-red-500/30 hover:shadow-xl hover:shadow-red-500/40 transform hover:scale-105"
            >
              <Calendar className="h-4 w-4 mr-2" />
              {language === 'fr' ? 'Réservation' : 'Booking'}
            </Link>
            
            {/* Bouton bleu - Estimation */}
            <Link
              to="/calculator"
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-4 py-2 rounded-lg transition-all duration-300 font-semibold shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/40 transform hover:scale-105"
            >
              {language === 'fr' ? 'Estimation' : 'Estimate'}
            </Link>
            
            <LanguageToggle />
            <ThemeToggle />
          </div>

          {/* Menu mobile button et toggles - DANS LE HEADER */}
          <div className="lg:hidden flex items-center space-x-3">
            <LanguageToggle />
            <ThemeToggle />
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-md text-white hover:text-red-400 hover:bg-red-900/20 transition-all duration-300 shadow-lg"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Menu mobile - PARFAIT SANS DÉBORDEMENT */}
        {isMenuOpen && (
          <div className="lg:hidden border-t border-gray-700/50 bg-black/95 backdrop-blur-sm">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-3 py-2 rounded-md text-base font-medium transition-all duration-300 ${
                    isActivePage(item.path)
                      ? 'text-red-400 bg-red-900/30 shadow-lg shadow-red-500/20'
                      : 'text-white hover:text-red-400 hover:bg-red-900/20'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
              
              {/* Boutons mobile */}
              <div className="pt-4 space-y-2">
                <Link
                  to="/service-booking"
                  onClick={() => setIsMenuOpen(false)}
                  className="flex items-center justify-center bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white px-4 py-3 rounded-lg transition-all duration-300 font-semibold w-full shadow-lg shadow-red-500/30"
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  {language === 'fr' ? 'Réservation' : 'Booking'}
                </Link>
                <Link
                  to="/calculator"
                  onClick={() => setIsMenuOpen(false)}
                  className="block text-center bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-4 py-3 rounded-lg transition-all duration-300 font-semibold w-full shadow-lg shadow-blue-500/30"
                >
                  {language === 'fr' ? 'Estimation' : 'Estimate'}
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
